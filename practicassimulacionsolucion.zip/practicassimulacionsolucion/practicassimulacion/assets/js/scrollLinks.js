
document.querySelectorAll('a[href="#miembros"], a[href="#colaboradores"]').forEach(link => {
    link.addEventListener('click', function(e) {
        e.preventDefault(); // evita el salto por defecto

        // mostrar la sección conocenos
        seccionInicio.style.display = "none";
        seccionConocenos.style.display = "block";

        // obtener el destino (#miembros o #colaboradores)
        const destino = document.querySelector(this.getAttribute('href'));
        if (destino) {
            // esperar un pequeño momento para que se renderice
            setTimeout(() => {
                destino.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }, 200);
        }
    });
});

