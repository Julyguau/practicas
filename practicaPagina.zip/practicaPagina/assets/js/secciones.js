

// -------------------------------
// CAMBIO ENTRE INICIO Y CONÓCENOS
// -------------------------------
const btnConocenos = document.getElementById("btnConocenos");
const btnInicio = document.getElementById("btnInicio");
const seccionInicio = document.getElementById("inicio");
const seccionConocenos = document.getElementById("conocenos");

btnConocenos.addEventListener("click", () => {
    seccionInicio.style.display = "none";
    seccionConocenos.style.display = "block";
});

btnInicio.addEventListener("click", () => {
    seccionConocenos.style.display = "none";
    seccionInicio.style.display = "flex";
});
