// -------------------------------
// SLIDER AUTOMÁTICO CON EFECTO FADE
// -------------------------------
const imagenes = document.querySelectorAll('.slides img');
let indice = 0;

function cambiarSlide() {
  imagenes.forEach(img => img.classList.remove('active'));
  indice = (indice + 1) % imagenes.length;
  imagenes[indice].classList.add('active');
}

imagenes[0].classList.add('active');
setInterval(cambiarSlide, 4000);
